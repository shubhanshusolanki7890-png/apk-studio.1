# APK Studio — Liquid Glass Mobile IDE & Android APK Builder

APK Studio is a mobile-first web development environment and Android application packager featuring a **Responsive Liquid Glass UI** with real-time SVG optical refraction (`#liquid-refraction`), an offline-capable **IndexedDB** workspace, a mobile-optimized **Code Editor**, an isolated **Sandboxed Live Preview** with virtual developer console, an **Icon / Splash / Permission Studio**, and an **Android Gradle + GitHub Actions CI/CD Build Engine**.

---

## 1. Repository Structure

```text
apk-studio/
├── .github/
│   └── workflows/
│       └── build-apk.yml         # Automated GitHub Actions APK build pipeline
├── app-shell/                    # Native Android WebView host application (Gradle 8.5 / AGP 8.2.2)
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml
│   │   │   ├── java/com/apkstudio/app/MainActivity.java
│   │   │   ├── res/              # Adaptive launcher icons, themes, and strings
│   │   │   └── assets/webapp/    # Bundled production Web IDE assets
│   │   ├── build.gradle
│   │   └── proguard-rules.pro
│   ├── gradle/wrapper/           # Gradle 8.5 wrapper JAR and properties
│   ├── build.gradle
│   ├── settings.gradle
│   ├── gradle.properties
│   ├── gradlew
│   └── gradlew.bat
├── web-ide/                      # React 18 + TypeScript + Vite Liquid Glass IDE
│   ├── src/
│   │   ├── components/           # LiquidGlassPanel, SidebarNav, ModalDialog
│   │   ├── features/
│   │   │   ├── overview/         # System Diagnostics & Pre-Flight Readiness
│   │   │   ├── workspace/        # Project Switcher, Templates, ZIP Import/Export, File Explorer
│   │   │   ├── editor/           # Multi-tab Code Editor with Mobile Symbol Bar & Find/Replace
│   │   │   ├── preview/          # Sandboxed iframe Preview & Virtual Developer Console
│   │   │   ├── studios/          # App Identity, Launcher Icon, Splash & Permission Studio
│   │   │   └── builder/          # Android Project ZIP Generator & Backend Build Client
│   │   ├── services/             # IndexedDB storage, JSZip archive, Templates, Android generator
│   │   ├── styles/               # Supplied Liquid Glass CSS (liquid-glass.css)
│   │   ├── App.tsx
│   │   └── main.tsx
│   ├── scripts/                  # Production bundler & offline-resilient AST compiler
│   ├── index.html                # Entry HTML with embedded #liquid-refraction SVG filter
│   ├── package.json
│   ├── tsconfig.json
│   └── vite.config.ts            # Outputs directly to ../app-shell/app/src/main/assets/webapp
├── backend/                      # Optional Node.js/TypeScript backend service for remote Gradle builds
├── scripts/
│   └── run-tests.cjs             # End-to-end verification & OpenJDK 17 compilation test suite
└── package.json
```

---

## 2. Compiling the Android APK on Your Phone via GitHub Actions (No Desktop Required)

1. Create or open a GitHub repository in your mobile browser or GitHub mobile app.
2. Upload the contents of `apk-studio.zip` (or upload `apk-studio.zip` directly to the repository root and copy `.github/workflows/build-apk.yml` into `.github/workflows/build-apk.yml`—the workflow automatically extracts the ZIP if uploaded as an archive).
3. Open the **Actions** tab in your GitHub repository.
4. Select **Build APK Studio Android APK** and tap **Run workflow**.
5. Once the workflow finishes (~2–3 minutes), scroll down to **Artifacts** and download **`apk-studio-debug-apk`**, which contains your installable `app-debug.apk`.

---

## 3. Local Development & Verification Commands

### Build the Web IDE into `app-shell/app/src/main/assets/webapp`
```bash
npm run build
```

### Run the Automated Verification Suite
```bash
npm test
```

### Compile the Android APK Locally (Requires JDK 17 + Android SDK 34)
```bash
cd app-shell
./gradlew assembleDebug
```
The compiled debug APK is written to:
`app-shell/app/build/outputs/apk/debug/app-debug.apk`
